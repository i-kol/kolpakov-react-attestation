import React from 'react'

export const Footer = () => {
  return (
    <div>
      <footer className="pt-4 my-md-5 pt-md-5 border-top">
      </footer>
    </div>
  )
}
