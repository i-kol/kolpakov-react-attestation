import React from 'react'

const item = (props) => {
  return (
    <div class="container py-3 ">
    <br/>
      <main>
        <div className="row row-cols-1 justify-content-evenly row-cols-md-3 mb-3 row-cols-sm-2 text-center">
          <div className="col px-3 py-3 ">
            <div className="card mb-6 rounded-4 ">
              <div className="card-header py-3 px-3">
                <button type="button" className="w-100 btn btn-lg btn-primary" >Добавить в избранное
                </button>
                <p>{props.title}</p>
                <img className='rounded' src={props.img} width={'85%'}/>
                <p>{props.description}</p>
                <p>{props.price}</p>
                <div>
                    <button type="button" className="w-100 btn btn-lg btn-primary">Оставить заявкy</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}

export default item