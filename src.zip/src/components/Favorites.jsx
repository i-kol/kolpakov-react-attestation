import React from 'react'

const Favorites = () => {

  return (
    <div>
      <div>
        <h1 className='col-md-8 offset-md-2'>Избранные туры</h1>
      </div>
    <div>
      
    </div>

    </div>

  )
}

export default Favorites