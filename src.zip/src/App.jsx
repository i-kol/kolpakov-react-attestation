
import 'bootstrap/dist/css/bootstrap.min.css';
import Header from './components/Header';
import Favorites from './components/Favorites';
import Home from './components/Home';
import Form from './components/Form';
import Description from './components/Description';
import './App.css'
import { Footer } from './components/Footer';
import { useState } from 'react';
import { useEffect } from 'react';
import axios from 'axios';
import {Route, Routes, BrowserRouter as Router} from'react-router-dom';

function App() {

// Хранение данных туров
const [tyrs, setTyrs] = useState([])

useEffect (()=> {

  async function axiosData() {
    const tyrsData = await axios.get('https://643aedc090cd4ba5630563d6.mockapi.io/tyrs')
    setTyrs(tyrsData.data)
  }
  axiosData();
},[])

  return (
    <div>
      <Router>
        <Header/>
        <Routes>
         
          <Route path='/favorites'
            element={
              <Favorites/>
            }
          />
          
          <Route path='/'
              element={
                <Home
                  item={tyrs}
                />
              }
            />

          <Route path='/form'
              element={
                <Form/>
              }
            />

          <Route path='/description'
            element={
              <Description/>
            }
          />

        </Routes>
      </Router>
      <Footer/>
    </div>
  );
}

export default App;
